package com.shopping.web.controllers;

public class UserController {

}
