package com.shopping.model.service.exceptions;

public class StoreNotFoundException extends RuntimeException {

	
	private static final long serialVersionUID = 1L;

}
