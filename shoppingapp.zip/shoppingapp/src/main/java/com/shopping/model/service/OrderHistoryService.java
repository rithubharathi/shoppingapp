package com.shopping.model.service;

import java.util.List;

import com.shopping.model.entities.OrderHistory;

public interface OrderHistoryService {
	List<OrderHistory> getAllOrderHistory();
}
